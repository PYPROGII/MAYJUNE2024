import csv as mycsv
import sqlite3
from sqlite3 import Error

db_name='a2CountryCode.db'

def test_db(db_name):
    dbconn = None  # database connect string
    try:
        dbconn = sqlite3.connect(db_name)
    except Error as e:
        print("Unable to open database", db_name, "\n\t\t\t",e)
    finally:
        dbCursor=dbconn.cursor()
        select_statement='''SELECT code, countryname FROM CountryCode ORDER BY code'''
        dbCursor.execute(select_statement)
        rows = dbCursor.fetchall()

        for row in rows:
            print(row)
        print('closing database',db_name )
        dbconn.close()
# --        
def create_db(dbname):
    dbconn = None  # database connect string
    try:
        dbconn = sqlite3.connect(dbname)
    except Error as e:
        print("Unable to create or open database", dbname, "\n\t\t\t",e)
    finally:
        return dbconn
          
# --                       ----
def main():
    dbconn=create_db(db_name)
    if dbconn:
        dbcursor = dbconn.cursor()
        dbcursor.execute('DROP TABLE IF EXISTS CountryCode')
        # --
        main_table_sql = '''CREATE TABLE IF NOT EXISTS CountryCode(
                            code PRIMARY KEY,
                            countryname NOT NULL
                            );'''
        dbcursor.execute(main_table_sql)
        insert_sql = '''INSERT INTO CountryCode(code,countryname) VALUES(''' 
        with open('AlfaCountryID2.csv', newline='') as csvctCode:
            rowcounter = 0
            ctcodereader = mycsv.reader(csvctCode,quotechar =',')
            for row in  ctcodereader:
                if rowcounter==0:
                    print('Headers\n', row,'\n')
                    rowcounter+=1
                elif len(row) !=8:
                    print('LENGTH =',len(row),row,'\n')
                elif row[7:8] != ['0NA']:
                    print(''.join(row[:1]),'\t\t\t',''.join(row[3:4]))
                    new_insert_sql = insert_sql+"'"+''.join(row[3:4]).strip()+"'"+",'"+''.join(row[:1]).replace("'"," ").strip()+"');"
                    dbcursor.execute(new_insert_sql)
        dbconn.commit()
        dbconn.close()
        
# -- Processing starts here
if __name__ == '__main__':
    main()

    print('-------- Test database ---------')
    test_db(db_name)



