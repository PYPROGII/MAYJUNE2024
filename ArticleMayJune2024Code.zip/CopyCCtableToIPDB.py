import sqlite3
from sqlite3 import Error
import os
def testTableMove(dbcur):
    print('------- Verify Data in new CountryCode Table -------')
    selectQuery='''SELECT * FROM CountryCode'''
    dbcur.execute(selectQuery)
    rows = dbcur.fetchall()
    for row in rows:
        print(row)
    return
# --
def open_db(dbname):
    dbconnection = None  # database connect string
    try:
        dbconnection = sqlite3.connect(dbname)
    except Error as e:
        print("Unable to open database", dbname, "\n\t\t\t",e)
        return dbconnection # -- NULL in this case
    finally:
        return dbconnection
    
# -- add from database   to database table 
def add_coutrycode_tble(dbcur1,dbcur2):
    # --
    dbcur1.execute('DROP TABLE IF EXISTS CountryCode')
    ccode_table_sql = '''CREATE TABLE IF NOT EXISTS CountryCode(
                        code PRIMARY KEY,
                        countryname NOT NULL
                        );'''
    
    dbcur1.execute(ccode_table_sql)
    
    select_statement='''SELECT code, countryname FROM CountryCode ORDER BY code'''
    dbcur2.execute(select_statement)
    rows = dbcur2.fetchall()
    
    for row in rows:
        # -
        insertQuery="INSERT INTO CountryCode (code, countryname ) VALUES (?,?)"
        dbcur1.execute(insertQuery,(row[0],row[1]))
    return

# --                       ----
def main():
    databaseName1 = 'ip_info_db.db'
    databaseName2 = 'a2CountryCode.db'
    if os.path.isfile(databaseName1) == True and \
       os.path.isfile(databaseName2) == True:
        dbconn1 = open_db(databaseName1 )
        if dbconn1:
            dbconn2 = open_db(databaseName2 )
            if dbconn2:
                print('connected to both databases')
                # --
                cur1=dbconn1.cursor()
                cur2=dbconn2.cursor()
                add_coutrycode_tble(cur1,cur2)
                # --
                dbconn1.commit()
                testTableMove(cur1)
                dbconn1.close()
                dbconn2.close()
            else:
                #list_by_country(dbconn)
                #country_totals(dbconn)
                print("Failed Connecting to:",databaseName2)
                dbconn.close()
        else:
            print("Failed Connecting to:",databaseName1)
    else:
        print("file",databaseName1,"or",databaseName2,"was not found!")
# -- Processing starts here
if __name__ == '__main__':
    main()
    
